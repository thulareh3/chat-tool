using System;
using System.Security.Claims;

namespace API.Extensions;

public static class ClaimPrincipalExtensions
{
    public static string GetuserName(this ClaimsPrincipal user)
    {
        var usernName = user.FindFirstValue(ClaimTypes.Name) ?? throw new Exception("Cannot get username");
        return usernName;
    }
    public static Guid GetUserId(this ClaimsPrincipal user)
    {
        return Guid.Parse(user.FindFirstValue(ClaimTypes.NameIdentifier) ?? throw new Exception("Cannot get userid"));
    }

}
