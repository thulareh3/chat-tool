using System;

namespace API.DTOs;

public class OnlineUserDto
{
    public string? Id { get; set; }
    public string? ConnectionId { get; set; }
    public string? Username { get; set; }
    public string? FullName { get; set; }
    public string? profileImage { get; set; }
    public bool IsOnline { get; set; }
    public int UnreadCount { get; set;}


}
