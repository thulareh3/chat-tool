using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Security.Claims;
using System.Threading.Tasks;
using API.Data;
using API.DTOs;
using API.Extensions;
using API.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;

namespace API.Hubs;

public class ChatHub(UserManager<AppUser> userManager, AppDbContext context) : Hub
{
    public static readonly ConcurrentDictionary<string, OnlineUserDto>
    onlineUsers = new();

    public override async Task OnConnectedAsync()
    {
        var httpContext = Context.GetHttpContext();
        var receivedid = httpContext?.Request.Query["senderId"].ToString();
        var userName = Context.User?.FindFirst(ClaimTypes.Name)?.Value
            ?? Context.User?.FindFirst(ClaimTypes.Email)?.Value;
        var currentuser = await userManager.FindByNameAsync(userName!);
        var connectionId = Context.ConnectionId;

        if (onlineUsers.TryGetValue(userName!, out OnlineUserDto? value))
        {
            value.ConnectionId = connectionId;
        }
        else
        {
            var user = new OnlineUserDto
            {
                ConnectionId = connectionId,
                Username = userName,
                profileImage = currentuser!.ProfileImage,
                FullName = currentuser.FullName,
            };

            onlineUsers.TryAdd(userName!, user);
            await Clients.AllExcept(connectionId).SendAsync("Notify", currentuser);
        }
        if (!string.IsNullOrEmpty(receivedid))
        {
            await LoadMessages(receivedid);
        }
        await Clients.All.SendAsync("OnlineUsers", await GetAllUsers());

    }

    public async Task SendMessage(MessageRequestDto message)
    {

        var senderId = Context.User!.Identity!.Name;
        var recipientId = message.ReceiverId;

        var newMsg = new Message
        {
            Sender = await userManager.FindByNameAsync(senderId!),
            Receiver = await userManager.FindByIdAsync(recipientId!),
            IsRead = false,
            Createddate = DateTime.UtcNow,
            Content = message.Content
        };

        context.Messages.Add(newMsg);
        await context.SaveChangesAsync();

        await Clients.User(recipientId!).SendAsync("ReceiveNewMessage", newMsg);


    }

    public async Task NotifyTyping(string recepientuserName)
    {
        var senderUserName = Context.User!.Identity!.Name;
        if (senderUserName is null)
        {
            return;
        }
        var connectionId = onlineUsers.Values.FirstOrDefault(x => x.Username == recepientuserName)?.ConnectionId;

        if (connectionId != null)
        {
            await Clients.Client(connectionId).SendAsync("NotifyTypingToUser", senderUserName);
        }

    }
    public override async Task OnDisconnectedAsync(Exception? exception)
    {
        var userName = Context.User!.Identity!.Name;
        onlineUsers.TryRemove(userName!, out _);
        await Clients.All.SendAsync("OnlineUsers", await GetAllUsers());
    }
    public async Task LoadMessages(string recepientId, int pageNumber = 1)
    {
        int pageSize = 1000;
        var userName = Context.User!.Identity!.Name;
        var currentUser = await userManager.FindByNameAsync(userName!);

        if (currentUser is null)
        {
            return;
        }

        List<MessageResponseDto> messages = await context.Messages
    .Where(x =>
        (x.ReceiverId == currentUser.Id && x.SenderId == recepientId) ||
        (x.SenderId == currentUser.Id && x.ReceiverId == recepientId))
    .OrderBy(x => x.Createddate)
    .Skip((pageNumber - 1) * pageSize)
    .Take(pageSize)
    .Select(x => new MessageResponseDto
    {
        Id = x.Id,
        Content = x.Content,
        CreatedDate = x.Createddate,
        ReceiverId = x.ReceiverId,
        SenderId = x.SenderId,
    })
    .ToListAsync();

        // Batch update read status
        var messageIdsToUpdate = messages
            .Where(m => m.ReceiverId == currentUser.Id)
            .Select(m => m.Id)
            .ToList();

        var unreadMessages = await context.Messages
            .Where(m => messageIdsToUpdate.Contains(m.Id))
            .ToListAsync();


        foreach (var msg in unreadMessages)
        {
            msg.IsRead = true;
        }
        await context.SaveChangesAsync();

        // Send to client
        await Clients.User(currentUser.Id)
            .SendAsync("ReceiveMessageList", messages);

    }
    public async Task LoadAllMessages(string senderId, int pageNumber = 1)
    {
        int pageSize = 1000;
        var userName = Context.User!.Identity!.Name;
        var currentUser = await userManager.FindByNameAsync(userName!);

        if (currentUser is null)
        {
            return;
        }

        List<MessageResponseDto> messages = await context.Messages
    .Where(x => x.SenderId == currentUser.Id)
    .OrderBy(x => x.Createddate)
    .Skip((pageNumber - 1) * pageSize)
    .Take(pageSize)
    .Select(x => new MessageResponseDto
    {
        Id = x.Id,
        Content = x.Content,
        CreatedDate = x.Createddate,
        ReceiverId = x.ReceiverId,
        SenderId = x.SenderId,
    })
    .ToListAsync();
        await context.SaveChangesAsync();
        await Clients.User(currentUser.Id)
            .SendAsync("ReceiveAllMessageList", messages);
    }
    public async Task<IEnumerable<OnlineUserDto>> GetAllUsers()
    {
        try
        {
            var username = Context.User?.GetuserName();
            if (string.IsNullOrEmpty(username))
                throw new HubException("User not authenticated");

            var onlineuserSet = new HashSet<string>(onlineUsers.Keys);

            var users = await userManager.Users.Select(u => new OnlineUserDto
            {
                Id = u.Id,
                Username = u.UserName,
                FullName = u.FullName,
                profileImage = u.ProfileImage,
                IsOnline = onlineuserSet.Contains(u.UserName!),
                UnreadCount = context.Messages.Count(x => x.ReceiverId ==
                    username && x.SenderId == u.Id && !x.IsRead)
            }).OrderByDescending(u => u.IsOnline)
            .ToListAsync();

            return users;
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error in GetAllUsers: " + ex.Message);
            throw new HubException("Failed to fetch users");
        }
    }

}
