import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { ApiResponse } from '../Models/api-response';

@Injectable({
  providedIn: 'root',
})
export class AuthServiceService {
  private baseUrl = 'http://localhost:5154/api/account';

  httpClient = inject(HttpClient);

  register(data: FormData): Observable<ApiResponse<string>> {
    return this.httpClient
      .post<ApiResponse<string>>(`${this.baseUrl}/register`, data)
      .pipe(
        tap((response) => {
          localStorage.setItem('regResponse', response.data);
        })
      );
  }
  private apiUrl = `${this.baseUrl}/login`;

  constructor(private http: HttpClient) {}

  login(email: string, password: string): Observable<any> {
    const payload = { email, password };

    return this.http.post<any>(this.apiUrl, payload).pipe(
      tap((res) => {
        if (res.isSuccess && res.data) {
          sessionStorage.setItem('authToken', res.data);
        }
      })
    );
  }
  getCurrentUser(): Observable<ApiResponse<any>> {
    const token = localStorage.getItem('authToken');

    return this.httpClient
      .get<ApiResponse<any>>(`${this.baseUrl}/me`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .pipe(
        tap((response) => {
          if (response.isSuccess && response.data) {
            localStorage.setItem('user', JSON.stringify(response.data));
          }
        })
      );
  }
  isLoggedIn(): boolean {
    const token = localStorage.getItem('authToken');
    return !!token && token.trim() !== '';
  }
  logout(): any {
    localStorage.clear();
  }
}
