import { inject, Injectable, signal } from '@angular/core';
import * as signalR from '@microsoft/signalr';
import { MessageRequestDto } from '../Models/message-request';
import { MessageResponseDto } from '../Models/message-response';
import { BehaviorSubject } from 'rxjs';
import { AuthServiceService } from './auth-service.service';
import { ChatSelectionService } from './chat-selection.service';

@Injectable({
  providedIn: 'root',
})
export class SignalRService {
  userJson = localStorage.getItem('user');
  loggedInUser = this.userJson ? JSON.parse(this.userJson) : null;
  private hubConnection!: signalR.HubConnection;
  public connectedUsers: string[] = [];
  public groupedMessages: any;
  private baseUrl = 'http://localhost:5154';
  chatselectionService = inject(ChatSelectionService);

  public users: any;
  messages = signal<any[]>([]);
  selectedUser: any;
  sendMessage(message: MessageRequestDto): void {
    this.hubConnection
      .invoke('SendMessage', message)
      .catch((err) => console.error('Send failed:', err));
  }
  startConnection(token: string, senderId?: string): void {
    this.hubConnection = new signalR.HubConnectionBuilder()
      .withUrl(`${this.baseUrl}/hubs/chat?senderId=${senderId || ''}`, {
        accessTokenFactory: () => token || '',
        transport: signalR.HttpTransportType.WebSockets,
      })
      .withAutomaticReconnect()
      .build();

    this.hubConnection.on('Notify', (user: any) => {
      Notification.requestPermission().then((permission) => {
        if (permission === 'granted') {
          new Notification('Active now', {
            body: `${user.fullName} is active now`,
            icon: user.profileImage,
          });
        }
      });
    });
    this.hubConnection!.on('NotifyTypingToUser', (senderUserName) => {
      this.users.map((user: any) => {
        if (user.userName === senderUserName) {
          user.isOnline = true;
        }
        return user;
      });
      setTimeout(() => {
        this.users.update((users: any[]) => {
          users.map((user) => {
            if (user.userName === senderUserName) {
              user.isTyping = true;
            }
            return user;
          });
        });
      }, 2000);
    });
    this.hubConnection
      .start()
      .then(() => {
        console.log('SignalR connected');
      })
      .catch((err) => console.error('SignalR error:', err));

    this.hubConnection!.on('Onlineusers', (user: any) => {
      const userJson = localStorage.getItem('user');
      const loggedInUser = userJson ? JSON.parse(userJson) : null;
      this.users = user.filter(
        (user: { username: any }) => user.username !== loggedInUser!.userName
      );
      localStorage.setItem('rusers', JSON.stringify(this.users));
    });
    this.hubConnection!.on('ReceiveAllMessageList', (users: any) => {
      const userJson = localStorage.getItem('user');
      const loggedInUser = userJson ? JSON.parse(userJson) : null;
      localStorage.setItem('rusers', JSON.stringify(this.users));
    });
    this.hubConnection!.on('ReceiveMessageList', (message) => {
      this.messages!.update((mesg) => [...message, mesg]);
      const enrichedMessages = message.map((msg: any) => ({
        ...msg,
        isMine: msg.senderId === this.loggedInUser!.id,
        direction: msg.senderId === this.loggedInUser!.id ? 'sent' : 'received',
      }));
      this.groupedMessages = enrichedMessages;
      localStorage.setItem('groupedMessages', JSON.stringify(enrichedMessages));
    });
  }
  loadMessages(receiverId: string, page: number): void {
    this.hubConnection
      .invoke('LoadMessages', receiverId, page)
      .then((message) => {})
      .catch((err) => console.error('LoadMessages failed:', err));
  }
  getAllMessages(senderId: string): void {
    this.hubConnection
      ?.invoke('LoadAllMessages', senderId, 1)
      .then((message) => {})
      .catch((err) => console.error('Error loading all messages:', err));
  }
  notifyTyping(): void {
    this.chatselectionService.selectedUser$.subscribe((user) => {
      if (user) {
        this.selectedUser = user;
      }
    });
    this.hubConnection!.invoke('NotifyTyping', this.selectedUser!.userName)
      .then((x: any) => {})
      .catch((err) => {
        console.log(err);
      });
  }
}
