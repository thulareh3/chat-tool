import {
  Component,
  ElementRef,
  HostListener,
  inject,
  ViewChild,
} from '@angular/core';
import { MatFormField } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInput } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatLabel } from '@angular/material/form-field';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { SignalRService } from 'src/app/Services/signal-r.service';
import { ChatSelectionService } from 'src/app/Services/chat-selection.service';
import { AuthServiceService } from 'src/app/Services/auth-service.service';
import { MessageRequestDto } from 'src/app/Models/message-request';
import { MatTableModule } from '@angular/material/table';
import { throwMatDuplicatedDrawerError } from '@angular/material/sidenav';

@Component({
  selector: 'app-chat-window',
  standalone: true,
  imports: [
    MatFormField,
    MatIconModule,
    MatInput,
    MatCardModule,
    MatToolbarModule,
    MatTableModule,
    FormsModule,
    CommonModule,
    MatLabel,
  ],
  templateUrl: './chat-window.component.html',
  styleUrl: './chat-window.component.css',
})
export class ChatWindowComponent {
  @ViewChild('chatMessages') chatMessages!: ElementRef;
  messagePollingInterval: any;

  scrollToBottom(): void {
    setTimeout(() => {
      const container = this.chatMessages.nativeElement;
      container.scrollTop = container.scrollHeight;
    }, 0);
  }

  newMessage: string = '';
  sigNalRService = inject(SignalRService);
  chatSelectionService = inject(ChatSelectionService);
  authService = inject(AuthServiceService);
  signalRService = inject(SignalRService);
  selectedUser: any;
  loggedInUser: any;
  defaultSelectedUser: any[] = [];
  messages: any[] = [];

  ngOnInit(): void {
    const userJson = localStorage.getItem('user');
    const loggedInUser = userJson ? JSON.parse(userJson) : null;
    const token = localStorage.getItem('authToken')?.toString() || '';

    this.signalRService.startConnection(token, loggedInUser!.id);

    this.chatSelectionService.selectedUser$.subscribe((user) => {
      if (user) {
        this.selectedUser = user;
      }
    });
    this.loggedInUser = userJson;

    this.startMessagePolling();
  }
  messageContent: string = '';

  sendMessage(): void {
    if (!this.messageContent.trim()) return;

    const message: MessageRequestDto = {
      id: 0,
      senderId: this.loggedInUser.id,
      receiverId: this.selectedUser.id,
      content: this.messageContent,
      isRead: false,
      createdDate: new Date().toISOString(),
    };

    this.signalRService.sendMessage(message);
    this.sigNalRService.loadMessages(this.selectedUser!.id, 1);
    this.messageContent = '';
  }
  ngOnDestroy(): void {
    this.stopMessagePolling();
  }

  stopMessagePolling(): void {
    if (this.messagePollingInterval) {
      clearInterval(this.messagePollingInterval);
      this.messagePollingInterval = null;
    }
  }

  startMessagePolling(): void {
    this.stopMessagePolling(); // clear any existing interval

    this.messagePollingInterval = setInterval(() => {
      if (this.selectedUser) {
        this.signalRService.loadMessages(this.selectedUser.id, 1);
      }
    }, 3000); // every 3 seconds
  }

  ngAfterViewChecked(): void {
    this.scrollToBottom();
  }
}
