import { Component, inject, signal } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
} from '@angular/forms';
import { MatFormField, MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AuthServiceService } from 'src/app/Services/auth-service.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { SignalRService } from 'src/app/Services/signal-r.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    MatFormField,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    CommonModule,
    FormsModule,
  ],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  loginForm: FormGroup;
  hidePassword = true;

  loginMessage = signal<string | null>(null);

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private authService: AuthServiceService,
    private router: Router,
    private signalRService: SignalRService
  ) {
    this.loginForm = this.fb.group({
      email: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  goToRegister() {
    this.router.navigate(['/register']);
  }

  onSubmit() {
    if (this.loginForm.invalid) return;

    const payload = {
      email: this.loginForm.value.email,
      password: this.loginForm.value.password,
    };

    const { email, password } = this.loginForm.value;

    this.authService.login(email, password).subscribe({
      next: (res) => {
        if (res.isSuccess && res.data) {
          localStorage.setItem('authToken', res.data);
          this.loginMessage.set(res.message || '✅ Login successful!');
          const userJson = localStorage.getItem('user');
          const loggedInUser = userJson ? JSON.parse(userJson) : null;
          const token = localStorage.getItem('authToken')?.toString() || '';
          this.router.navigate(['chat']);
        }
      },
      error: () => {
        this.loginMessage.set(
          '❌ Login failed. Please check your credentials.'
        );
      },
    });
  }
}
