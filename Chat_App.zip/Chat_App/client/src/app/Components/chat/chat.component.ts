import { Component } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
} from '@angular/forms';
import { MatIcon } from '@angular/material/icon';
import { MatToolbar } from '@angular/material/toolbar';
import { MatListItem } from '@angular/material/list';
import { MatNavList } from '@angular/material/list';
import { MatFormField } from '@angular/material/form-field';
import { MatLabel } from '@angular/material/form-field';
import { ChatSidebarComponent } from '../chat-side-bar/chat-side-bar.component';
import { ChatWindowComponent } from '../chat-window/chat-window.component';
import { Router } from '@angular/router';
import { AuthServiceService } from 'src/app/Services/auth-service.service';
import { SignalRService } from 'src/app/Services/signal-r.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    ChatSidebarComponent,
    ChatWindowComponent,
    CommonModule,
    MatIcon,
    MatToolbar,
    MatListItem,
    MatNavList,
    MatFormField,
    MatLabel,
  ],
  templateUrl: './chat.component.html',
  styleUrl: './chat.component.css',
})
export class ChatComponent {
  user: any = {};
  users: any;
  constructor(
    private router: Router,
    private authService: AuthServiceService,
    private signalRService: SignalRService
  ) {}
  ngOnInit() {
    this.authService.getCurrentUser().subscribe({
      next: (res) => {
        this.user = res.data;
      },
      error: () => {},
    });
  }
  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }
  goHome() {
    this.router.navigate(['/chat']);
  }
  ngOnDestroy() {
    localStorage.clear();
  }
}
