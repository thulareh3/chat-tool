import { Component, OnInit } from '@angular/core';
import * as signalR from '@microsoft/signalr';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { Router } from '@angular/router';
import { AuthServiceService } from 'src/app/Services/auth-service.service';
import { SignalRService } from 'src/app/Services/signal-r.service';
import { ChatSelectionService } from 'src/app/Services/chat-selection.service';
import { MatTable, MatTableModule } from '@angular/material/table';

@Component({
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatSidenavModule,
    MatToolbarModule,
    MatFormFieldModule,
    MatInputModule,
    MatListModule,
    MatIconModule,
    MatTable,
    MatTableModule,
  ],
  selector: 'app-chat-sidebar',
  templateUrl: './chat-side-bar.component.html',
  styleUrls: ['./chat-side-bar.component.css'],
})
export class ChatSidebarComponent implements OnInit {
  isLargeScreen = window.innerWidth > 768;

  showLogout = false;
  searchTerm = '';
  isTyping = false;
  filteredChats: any[] = [{}];
  ngOnInit(): void {
    const userJson = localStorage.getItem('user');
    const loggedInUser = userJson ? JSON.parse(userJson) : null;
    const token = localStorage.getItem('authToken')?.toString() || '';
    this.signalRService.startConnection(token, loggedInUser!.id);
    //this.signalRService.getAllMessages(loggedInUser!.id);
  }
  constructor(
    private authService: AuthServiceService,
    private router: Router,
    protected signalRService: SignalRService,
    private chatSelectionService: ChatSelectionService
  ) {}
  loadUsers(): void {
    this.filteredChats = [...this.signalRService!.users];
  }

  filterusers(): void {
    this.filteredChats = [
      ...this.signalRService!.users!.filter((chat: any) =>
        chat
          .fullName!.toLowerCase()
          .includes(this.searchTerm!.toLowerCase().trim())
      ),
    ];
  }
  openConversation(user: any): void {
    this.chatSelectionService.selectUser(user);
    this.signalRService.loadMessages(user.id, 1);
    localStorage.setItem('selectedUser', JSON.stringify(user));
  }
  logout() {
    this.authService.logout();
    this.router.navigate(['login']);
  }
}
