import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter, Routes } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { loginGuard } from './guards/login.guard';
import { ChatComponent } from './Components/chat/chat.component';
import { authGuard } from './guards/auth.guard';

const routes: Routes = [
    {
    path : 'chat',
    component: ChatComponent,
    canActivate: [authGuard]
  },
  {
    path : 'register',
    loadComponent: () =>
      import('./Components/register/register.component').then((x)=> x.RegisterComponent),
    canActivate: [loginGuard]
  },
  {
    path : 'login',
    loadComponent: () =>
      import('./Components/login/login.component').then((x)=> x.LoginComponent),
    canActivate: [loginGuard]
  },
  {
    path: '**',
    redirectTo: 'chat',
    pathMatch : 'full'
  }
  
];

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideHttpClient(),
  ],
};