/** @type {import('tailwindcss').Config} */
export const content = [
    "./src/**/*.{html,ts}", // 👈 Angular templates & components
];
export const theme = {
    extend: {},
};
export const plugins = [];
