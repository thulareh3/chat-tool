export interface MessageResponseDto {
  id: number;
  senderId?: string;
  receiverId?: string;
  content?: string;
  createdDate?: string;
}