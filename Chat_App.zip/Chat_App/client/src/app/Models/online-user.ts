export interface OnlineUserDto {
  id?: string;
  connectionId?: string;
  username?: string;
  fullName?: string;
  profileImage?: string;
  isOnline: boolean;
  unreadCount: number;
}