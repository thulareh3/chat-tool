export interface MessageRequestDto {
  id: number;
  senderId?: string;
  receiverId?: string;
  content?: string;
  isRead: boolean;
  createdDate?: string;
}